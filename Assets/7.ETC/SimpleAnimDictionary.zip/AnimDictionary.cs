using System.Collections.Generic;
using UnityEngine;

// AnimType은 프로젝트에서 별도로 정의하세요.
// public enum AnimType { Idle, Run, Attack1 ... }

public class AnimDictionary
{
    private Dictionary<AnimType, AnimationClip> dict 
        = new Dictionary<AnimType, AnimationClip>();

    public void Add(AnimType type, AnimationClip clip)
    {
        if (clip == null) return;
        dict[type] = clip; // 덮어쓰기 허용
    }

    public AnimationClip Get(AnimType type)
    {
        dict.TryGetValue(type, out var clip);
        return clip;
    }

    public void Clear()
    {
        dict.Clear();
    }
}
