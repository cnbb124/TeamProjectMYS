using UnityEngine;

[CreateAssetMenu(menuName = "Anim/AnimData")]
public class AnimData : ScriptableObject
{
    public AnimEntry[] animList;
}
