using UnityEngine;

[System.Serializable]
public class AnimEntry
{
    public AnimType type;
    public AnimationClip clip;
}
