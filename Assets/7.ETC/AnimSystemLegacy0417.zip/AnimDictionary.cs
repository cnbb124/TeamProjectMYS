using System.Collections.Generic;
using UnityEngine;

public class AnimDictionary
{
    private Dictionary<AnimType, AnimationClip> animDict = new Dictionary<AnimType, AnimationClip>();

    public void Init(AnimEntry[] animList)
    {
        animDict.Clear();

        foreach (var entry in animList)
        {
            if (entry.clip == null)
            {
                Debug.LogWarning($"[Anim] 클립 없음: {entry.type}");
                continue;
            }

            if (animDict.ContainsKey(entry.type))
            {
                Debug.LogWarning($"[Anim] 중복 타입: {entry.type}");
                continue;
            }

            animDict.Add(entry.type, entry.clip);
        }
    }

    public AnimationClip Get(AnimType type)
    {
        if (animDict.TryGetValue(type, out var clip))
            return clip;

        Debug.LogWarning($"[Anim] 클립 없음: {type}");
        return null;
    }
}
