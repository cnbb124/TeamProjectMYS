#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(AnimData))]
public class AnimDataEditor : Editor
{
    public override void OnInspectorGUI()
    {
        AnimData data = (AnimData)target;

        if (GUILayout.Button("Auto Generate From Enum"))
        {
            var values = System.Enum.GetValues(typeof(AnimType));
            data.animList = new AnimEntry[values.Length];

            for (int i = 0; i < values.Length; i++)
            {
                data.animList[i] = new AnimEntry
                {
                    type = (AnimType)values.GetValue(i)
                };
            }

            EditorUtility.SetDirty(data);
        }

        DrawDefaultInspector();
    }
}
#endif
